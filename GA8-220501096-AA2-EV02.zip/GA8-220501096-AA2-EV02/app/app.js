const express = require("express");
const mysql = require("mysql");
const path = require("path");

const app = express();
app.set("port", 3001);

// Middleware para analizar el cuerpo de las solicitudes
app.use(express.urlencoded({ extended: true })); // Para formularios
app.use(express.json()); // Para datos JSON

// Configurar la conexión a la base de datos MySQL
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'db_reposteria'
});

// Conectar a MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error conectando a MySQL: ' + err.stack);
    return;
  }
  console.log('Conectado a la base de datos MySQL como id ' + connection.threadId);
});

// Middleware para servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Ruta para crear perfil (guardar en la base de datos)
app.post("/ruta-para-guardar", (req, res) => {
  // Log de los datos recibidos
  console.log("Datos recibidos:", req.body); // Para verificar qué se está enviando

  const { nombre, cargo, contraseña, conf_contrasena } = req.body;

  // Validar si los campos son vacíos
  if (!nombre || !cargo || !contraseña || !conf_contrasena) {
    return res.status(400).send("Todos los campos son obligatorios");
  }

  // Validar si las contraseñas son iguales
  if (contraseña !== conf_contrasena) {
    return res.status(400).send("Las contraseñas no coinciden");
  }

  // Insertar los datos en la base de datos
  const sql = "INSERT INTO empleados (nombre, cargo, contraseña) VALUES (?, ?, ?)";
  connection.query(sql, [nombre, cargo, contraseña], (err, results) => {
    if (err) {
      return res.status(500).send("Error al guardar el empleado: " + err);
    }
    res.status(200).send("Perfil creado con éxito");
  });
});

// Arrancar el servidor
app.listen(app.get("port"), () => {
  console.log("Servidor corriendo en el puerto", app.get("port"));
});
